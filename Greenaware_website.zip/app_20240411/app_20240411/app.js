//author: zaynab mirza 220467

const express = require('express')
const app = express()
const port = 3000

//direct express to static assets
app.use(express.static("public"));

//enables transfer of post data from html forms
app.use(express.urlencoded({extended: true}));

//set ejs as default template engine
app.set('view engine', 'ejs');
app.set('views', [__dirname + "/views",__dirname + "/views"]);

//mongodb ORM middleware
const mongoose = require("./config/dbconfig")

//session-based authorisation middleware
const session = require("express-session");

app.use(
    session({
    secret: "randomisedtext",
    resave: false,
    saveUninitialized: false,
    })
);

//authentication middleware
const passport = require("passport");
app.use(passport.initialize());
app.use(passport.session());

//store route endpoints separately for Separation of Concerns principle
require('./routes/userroutes')(app)
require('./routes/observerroutes')(app)
require('./routes/supportroutes')(app)

app.listen(port, () => {
    console.log(`App listening on port http://localhost:${port}`)
})