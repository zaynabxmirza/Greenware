import chai from 'chai';
import chaiHttp from 'chai-http';
const app = require('../app.js');
const User = require('../models/user.js');
const bcrypt = require('bcrypt');

// Configure Chai
chai.use(chaiHttp);
const expect = chai.expect;

describe('User Routes', () => {
  // Clear the User collection before running tests
  beforeEach(async () => {
    await User.deleteMany({});
  });

  describe('POST /register', () => {
    it('should register a new user', async () => {
      const userData = {
        forename: 'John',
        surname: 'Doe',
        username: 'johndoe',
        password: 'password123',
        address: {
          buildingNumber: '9',
          streetName: 'Baker Street',
          postcode: 'VD5 8DF',
          town: 'lonfon'
        },
        cardDetails: {
          cardName: 'John Doe',
          cardNumber: '123456789023',
          cardType: 'Visa',
          cardCVV: '123'
        },
        notificationPreference: 'Text'
      };

      const res = await chai.request(app)
        .post('/register')
        .send(userData);

      expect(res).to.have.status(302); // redirecting after successful registration

      // Check if user is registered in the database
      const user = await User.findOne({ username: userData.username });
      expect(user).to.exist;
      expect(user.forename).to.equal(userData.forename);
    });
  });
//testcases
});