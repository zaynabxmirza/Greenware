module.exports = function (app) {
  //connect to the database using the details from the dbconfig file

  const mongoose = require("../config/dbconfig");
  const User = require("../models/user");
  const Observation = require("../models/observation");
  const passport = require("passport");

  passport.use(User.createStrategy());
  passport.serializeUser(User.serializeUser());
  passport.deserializeUser(User.deserializeUser());

  checkAuth = (req, res, next) => {
    // passport adds this to the request object
    if (req.isAuthenticated()) {
      return next();
    }
    res.redirect("/login");
  };

  //to serve static files from current location, determine parent directory
  const path = require("path");
  const parentDirectory = path.dirname(__dirname);

  //hashing passwords
  const bcrypt = require("bcrypt");
  const saltRounds = 10;

  //---------------------index page-----------
  app.get("/", (req, res) => {
    res.render("index");
  });

  //---------------------------register a user-----------------------------------
  app.get("/register", (req, res) => {
    res.render("register");
  });

  app.post("/register", async (req, res) => {
    try {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(req.body.password, salt);
      const hashedCardNumber = await bcrypt.hash(req.body.cardNumber, salt);
      const hashedCVV = await bcrypt.hash(req.body.cardCVV, salt);
      const newUser = new User({
        forename: req.body.forename,
        surname: req.body.surname,
        username: req.body.username,
        password: hashedPassword,
        address: {
          buildingNumber: req.body.buildingNumber,
          streetName: req.body.streetName,
          postcode: req.body.postcode,
          town: req.body.town,
        },
        category: req.body.category,
        status: req.body.status,
        accountBalance: req.body.accountBalance,
        cardDetails: {
          cardNumber: hashedCardNumber,
          cardName: req.body.cardName,
          cardType: req.body.cardType,
          cardCVV: hashedCVV
        },
        notificationPreference: req.body.notificationPreference,
      });

      await User.register(newUser, req.body.password)
      // Save the user to the database
      await newUser.save();
      
      //redirect to login after successful registration
      res.redirect("login");
    } catch (err) {
      console.log(err);
      res.render("register");
    }
  });

  //----------------------------------user login---------------------------------
  app.get("/login", (req, res) => {
    res.render("login");
    });

  app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
      if (err) {
        console.log('authentication error: ', err)
        return next(err);
      }
  
      if (!user) {
        //failed authentication
        console.log('authentication failed:', info)
        return res.redirect('/login');
      }
  
      // succeeded authenticayion
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        
        // Debug session data -> who is currently accessing
        console.log('Session:', req.session);
        console.log('User in session:', req.user);
        
        // redirection based on user category
      if (user.category === 'Observer') {
        return res.redirect('/observer-dashboard');
      } else if (user.category === 'Support') {
        return res.redirect('/support-dashboard');
      } else {
        //Handle other user categories or redirect to a default page
        return res.redirect('/');
      }
      });
    })(req, res, next);
  });

  //------------------------------observer login-----------------
  app.get('/observer-dashboard', (req, res) => {
    if (req.user.category === 'Observer') {
      console.log(`Authenticated at /ob dashboard: ${req.isAuthenticated()}`);
      res.render("observer-dashboard");
    } else {
      res.redirect("/login");
    }
  });

  //-----------------------------user logout-----------------------
  app.get("/logout", (req, res) => {
    console.log(`Authenticated at /logout: ${req.isAuthenticated()}`);
    req.logout(function (err) {
      if (err) {
        return next(err);
      }
      console.log("User has been logged out");
      res.redirect("/");
    });
  });

  //----------------------------view all users--------------------------
  app.get("/users/getusers", async (req, res) => {
    try {
      const qryRes = await User.find();
      res.render("getusers", { users: qryRes });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  //---------------------------view one document-------------------------
  app.get("/users/queryuserbyid", async (req, res) => {
    //query all users' documents
    try {
      const qryRes = await User.find();
      //render page with form to accept choice for one user
      res.render("queryuserbyid", { users: qryRes });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/users/queryuser", async (req, res) => {
    //query document based on specific id passed through POST method
    try {
      const qryRes = await User.findById(req.body._id);
      //render form with document relating to specific user
      res.render("queryuser", { user: qryRes });
    } catch (error) {
      console.log(error)
      res.status(500).json({ message: error.message });
    }
  });

  //-------------------------delete one document------------------------
  app.get("/users/deleteuserbyid", async (req, res) => {
    //query all users' documents
    try {
      const qryRes = await User.find();
      //render page with form to accept choice for document deletion
      res.render("deleteuserbyid", { users: qryRes });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/users/deleteuser", async (req, res) => {
    //delete document based on specific id passed through POST method
    try {
      const id = req.body._id;
      console.log(`${id} has been removed from the database`);
      const qryRes = await User.findByIdAndDelete(id);
      //show effect of deletion by redirecting to show all documents
      res.redirect("/users/getusers");
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  //-------------------------update one document------------------------
  app.get("/users/updateuser", async (req, res) => {
    //query all users' documents
    try {
      const qryRes = await User.find();
      //render page with form to accept choice for update
      res.render("updateuser", { users: qryRes });
      }
      catch (error) {
      res.status(500).json({ message: error.message });
      }
      });      

  app.post("/users/updateuser", async (req, res) => {
    try {
      const filter = req.body._id;
      const updateQry = req.body;
      const options = { new: true };
      const qryRes = await User.findByIdAndUpdate(
        filter, updateQry, options
      )
      // show effect of update by redirecting to show all documents
      res.redirect("/users/getusers");
    }
    catch (error) {
      res.status(400).json({ message: error.message })
    }
  });

  //------------------------------about us page-----------------
  app.get('/aboutus', (req, res) => {
    res.render("aboutus");
  });

  //-------------------------------contact us page---------------
  app.get('/contactus', (req, res) => {
    res.render("contactus");
  });

//----------------------view to delete observer------
  app.get("/accountdeleted", (req, res) => {
    res.render("accountdeleted");
  });

  //---------------------delete a observer--------------------
app.get("/deleteaccount", async (req, res) => {
  try {
    // Get the current user's details
    const user = req.user;

    // Render the delete account confirmation page with the user's details
    res.render("deleteaccount", { user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.post("/deleteaccount", async (req, res) => {
  try {
    //get user's ID
    const userId = req.user._id;
    console.log("User ID:", userId);

    // delete the account
    const deletedUser = await User.findByIdAndDelete(userId);
    console.log("Deleted User:", deletedUser);

    if (!deletedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    req.logout(function(err) {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: "Error logging out" });
      }
      console.log("Logged out.");
      res.redirect("/accountdeleted");
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

}