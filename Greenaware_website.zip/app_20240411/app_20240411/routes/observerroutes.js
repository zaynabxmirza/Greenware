const observation = require("../models/observation");
const message = require('../models/message');

module.exports = function (app) {
    //connect to the database using the details from the dbconfig file
    const mongoose = require("../config/dbconfig");
    const User = require("../models/user");
    const Observation = require("../models/observation");
    const passport = require("passport");
    const message = require('../models/message');

    passport.use(User.createStrategy());
    passport.serializeUser(User.serializeUser());
    passport.deserializeUser(User.deserializeUser());
  
    //to serve static files from current location, determine parent directory
    const path = require("path");
    const parentDirectory = path.dirname(__dirname);
  
    checkAuth = (req, res, next) => {
      // passport adds this to the request object
      if (req.isAuthenticated()) {
        return next();
      }
      res.redirect("/login");
    };

//----------------------submit an observation--------------
app.get("/submitanobservation", (req, res) => {
    res.render("observations");
  });

  app.post("/submitanobservation", (req, res) => {
    const userId = req.user._id;

    const newObservation = new Observation({
      userId: userId,
      date: req.body.date,
      time: req.body.time,
      w3w: req.body.w3w,
      decimalDegrees: req.body.decimalDegrees,
      temperatureLand: req.body.temperatureLand,
      temperatureSea: req.body.temperatureSea,
      humidity: req.body.humidity,
      windSpeed: req.body.windSpeed,
      windDirection: req.body.windDirection,
      precipitation: req.body.precipitation,
      haze: req.body.haze,
      notes: req.body.notes,

    });

    newObservation.save();
    res.redirect("observer-dashboard");
  });

  //------------------------view an observation---------------------
  app.get("/viewobservation", async (req, res) => {
    try{
      const userId = req.user._id;
      const qryRes = await Observation.find({ userId: userId });
      //render page with form to accept choice for one user
      res.render("viewobservation", { observations: qryRes });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/viewobservation", async (req, res) => {
    //query observation documents
    try {
      const qryRes = await Observation.find();
    //render page with all obs documents      
    res.render("viewobservation", { observations: qryRes });
    } catch (error) {
      console.log(error)
      res.status(500).json({ message: error.message });
    }
});

//-------------------------update observer details (their own)-----------------
app.get("/updatedetails", async (req, res) => {
  try {
    // retrieve the current user's details
    const user = req.user;

    // render the update details form with the user's existing details
    res.render("updatedetails", { user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.post("/updatedetails", async (req, res) => {
  try {
    // Get the current user's ID
    const userId = req.user._id;

    // Update the user's details
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      req.body,
      { new: true, runValidators: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Redirect to the observer dashboard or render a success message
    res.redirect("/observer-dashboard");
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

  //-------------------------check message---------------------
  app.get('/messages', checkAuth, async (req, res) => {
      try{
        if (req.user.category === 'Observer') {
        // fetch support from db
          const supportUsers = await User.find({ category: 'Support' }).exec();
          
          //fetch messages for observer
          const messages = await message.find({
            $or: [{ sender: req.user._id }, { recipient: req.user._id }],
      })
        .populate('sender', 'username')
        .populate('recipient', 'username')
        .exec();
  
      res.render('observermessage', { supportUsers, messages, currentUserId: req.user._id });
    } else {
      res.status(403).send('Unauthorised');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to send a message from an observer to support
app.post('/messages/send', async (req, res) => {
  try {
    // Extract message data from the request body
    const { recipientId, content } = req.body;
    const observerId = req.user._id.toString();

    // Create a new message object
    const newMessage = new message({
      sender: observerId,
      recipient: recipientId,
      content: content
    });

    // Save the message to the database
    await newMessage.save();
    res.redirect('/messages');
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});
}