module.exports = function (app) {
    //connect to the database using the details from the dbconfig file
    const mongoose = require("../config/dbconfig");
    const Support = require("../models/support");
    const User = require("../models/user");
    const Observation = require("../models/observation");
    const message = require('../models/message');

    const passport = require("passport");

    passport.use(User.createStrategy());
    passport.serializeUser(User.serializeUser());
    passport.deserializeUser(User.deserializeUser());

  checkAuth = (req, res, next) => {
    // passport adds this to the request object
    if (req.isAuthenticated()) {
      return next();
    }
    res.redirect("/login");
  };

    //to serve static files from current location, determine parent directory
    const path = require("path");
    const parentDirectory = path.dirname(__dirname);

    //hashing passwords
    const bcrypt = require("bcrypt");

    //-----------------register for support-----------
    app.get('/register/support', (req, res) => {
        res.render("registersupport");
    })

    app.post("/register/support", async (req, res) => {
        try {
          const salt = await bcrypt.genSalt(10);
          const hashedPassword = await bcrypt.hash(req.body.password, salt);
          const newSupport = new Support({
            forename: req.body.forename,
            surname: req.body.surname,
            username: req.body.username,
            password: hashedPassword,
            
          });
          //register support
          await Support.register(newSupport, req.body.password)
          //Save the user to the database
          await newSupport.save();
          
          //redirect to login after successful registration
          res.redirect("/support-dashboard");
        } catch (err) {
          console.log('error: ', err);
          res.status(500).render("registersupport",{ error: "An error occurred during registration" });
        }
      });

    //------------------------------support login---------------------
    app.get("/support-dashboard", checkAuth, (req, res) => {
        if (req.user.category === 'Support') {
        console.log(`Authenticated at /sup dashboard: ${req.isAuthenticated()}`);
        res.render("support-dashboard");
        } else {
        res.redirect("/login");
        }
    });

    //----------------------------inbox for support----------------------------
    app.get('/inbox', checkAuth, async (req, res) => {
        try {
          const observerUsers = await User.find({ category: 'Observer' }).exec();
          const messages = await message.find({
            $or: [{ sender: req.user._id }, { recipient: req.user._id }],
          })
            .populate('sender', 'username')
            .populate('recipient', 'username')
            .exec();
      
          res.render('supportmessage', { observerUsers, messages, currentUserId: req.user._id });
      } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
        }
      });
      
      // Route to send a message from a support user to an observer
      app.post('/inbox/send', checkAuth, async (req, res) => {
        try {
          // Extrat message data from the request body
          const { recipientId, content } = req.body;
          const supportId = req.user._id.toString();
      
          const newMessage = new message({
            sender: supportId,
            recipient: recipientId,
            content: content,
          });
      
          await newMessage.save();
          res.redirect('/inbox');
        } catch (error) {
          console.error(error);
          res.status(500).json({ message: 'Internal Server Error' });
        }
      });
};