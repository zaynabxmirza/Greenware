const mongoose = require('mongoose');

//define a schema for the observations
const ObservationSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: {type: Date, default: Date.now},  
    time: {type: String},
    w3w: {type: String }, 
    decimalDegrees: {type: Number },
    temperatureLand: { type: Number},
    temperatureSea: {type: Number},
    humidity: {type: Number},
    windSpeed: { type: Number},
    windDirection: { type: Number},
    precipitation:  {type: Number},
    haze: {type: Number},
    notes: {type: String}
});

//instantiate observation model
const Observation = mongoose.model('Observation', ObservationSchema);

//export function to create Observation model class
module.exports = mongoose.model('Observation', ObservationSchema)