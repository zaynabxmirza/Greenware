const mongoose = require('mongoose');
passportLocalMongoose = require("passport-local-mongoose");

//define a schema for support
const  SupportSchema = new mongoose.Schema({
    username: { type: String}, 
    password: {type:String},
    forename: {type: String},
    surname: { type: String},
    category: { type: String, enum: ['Support', 'Observer'], default: 'Support'}
});

SupportSchema.plugin(passportLocalMongoose);

//instantiate observation model
const Support = mongoose.model('Support', SupportSchema);

//export function to create support model class
module.exports= mongoose.model("Support", SupportSchema);