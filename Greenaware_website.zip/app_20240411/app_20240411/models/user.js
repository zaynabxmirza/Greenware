const mongoose = require('mongoose');
passportLocalMongoose = require("passport-local-mongoose");


//define a schema for user/observer
const UserSchema = new mongoose.Schema({
    username: { type: String },
    password: { type: String },
    forename : { type: String },
    surname : { type: String },
    address:{ 
        buildingNumber: {type: Number},
        streetName: {type:String},
        postcode: {type: String},
        town: {type: String},
    },
    category: {type: String, enum: ['Support', 'Observer'], default: 'Observer'},
    status: { type: String, enum: ['active', 'inactive', 'disabled'], default: "active" }, 
    accountBalance: { type: Number, default: 0 }, //default account balance to 0
    cardDetails: {
        cardNumber: { type: String}, 
        cardName: { type: String}, 
        cardType: { type: String },
        cardCVV: { type: String }, 
    },
    notificationPreference: { type: String } 
});

UserSchema.plugin(passportLocalMongoose);

//instantiate user model
const User = mongoose.model('User', UserSchema);

//export function to create User model class
module.exports = mongoose.model('User', UserSchema)